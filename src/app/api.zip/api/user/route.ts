import { NextRequest, NextResponse } from "next/server";
import { getGebruikerViaCookies } from "@/lib/auth"; // of jouw manier van authenticatie

export async function GET(req: NextRequest) {
  try {
    const gebruiker = await getGebruikerViaCookies(req); // zelf aanpassen aan jouw systeem

    if (!gebruiker) {
      return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });
    }

    return NextResponse.json({
      naam: gebruiker.naam,
      email: gebruiker.email,
    });
  } catch (err) {
    return NextResponse.json({ error: "Fout bij ophalen gebruiker" }, { status: 500 });
  }
}
