"use client";

import { useEffect, useState } from "react";
import { format, parseISO } from "date-fns";
import { nl } from "date-fns/locale";
import Link from "next/link";
import ScrollToTopButton from "@/components/ScrollToTopButton";

type Dienst = {
  id: string;
  date: string;
  starttime: string;
  endtime: string;
  description: string;
  shift: {
    long_name: string;
    color: string;
  };
};

export default function OpenDienstenPerWeek() {
  const [data, setData] = useState<Dienst[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const today = new Date();
    const inFourWeeks = new Date();
    inFourWeeks.setDate(today.getDate() + 100);

    const min = today.toISOString().slice(0, 10);
    const max = inFourWeeks.toISOString().slice(0, 10);

    fetch(`/api/shiftbase/open-diensten?min_date=${min}&max_date=${max}`)
      .then((res) => res.json())
      .then((json) => {
        const diensten = json.data.map((item: any) => ({
          ...item.OpenShift,
          shift: item.Shift,
        }));
        setData(diensten);
        setLoading(false);
      });
  }, []);

 const exportToPDF = async () => {
  // @ts-expect-error: html2pdf.js heeft geen types
    const html2pdf = (await import("html2pdf.js")).default;
    const element = document.getElementById("pdf-content");
    if (!element) return;

    html2pdf()
      .set({
        margin: 0.5,
        filename: "OpenDiensten.pdf",
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
      })
      .from(element)
      .save();
  };

  if (loading) return <p className="p-4">Laden…</p>;

  const dienstenPerWeek: Record<string, Dienst[]> = {};
  data.forEach((d) => {
    const week = getWeekNumber(d.date);
    if (!dienstenPerWeek[week]) dienstenPerWeek[week] = [];
    dienstenPerWeek[week].push(d);
  });

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
<Link href="/" className="inline-flex items-center text-sm text-blue-600 hover:underline gap-1">
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 9.75L12 3l9 6.75v9a1.5 1.5 0 01-1.5 1.5h-15A1.5 1.5 0 013 18.75v-9z" />
  </svg>
  Start
</Link>

        <button
          onClick={exportToPDF}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm"
        >
          📄 Download als PDF
        </button>
      </div>

      <div id="pdf-content">
        <h1 className="text-2xl font-bold mb-6">Open diensten per week</h1>
        {Object.entries(dienstenPerWeek)
          .sort(([a], [b]) => Number(a) - Number(b))
          .map(([weekNr, diensten]) => (
            <div key={weekNr} className="mb-8">
              <h2 className="text-xl font-semibold mb-2">Week {weekNr}</h2>
              <table className="w-full border border-gray-300 text-sm table-fixed">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border px-3 py-2 text-left w-[20%]">Datum</th>
                    <th className="border px-3 py-2 text-left w-[10%]">Dag</th>
                    <th className="border px-3 py-2 text-left w-[20%]">Starttijd</th>
                    <th className="border px-3 py-2 text-left w-[20%]">Eindtijd</th>
                    <th className="border px-3 py-2 text-left w-[30%]">Dienst</th>
                  </tr>
                </thead>
                <tbody>
                  {diensten
                    .sort((a, b) => a.date.localeCompare(b.date))
                    .map((d) => (
                      <tr key={d.id} className="align-top">
                        <td className="border px-3 py-2">
                          {format(parseISO(d.date), "dd-MM-yyyy")}
                        </td>
                        <td className="border px-3 py-2">
                          {format(parseISO(d.date), "eee", { locale: nl })}
                        </td>
                        <td className="border px-3 py-2">{d.starttime}</td>
                        <td className="border px-3 py-2">{d.endtime}</td>
                        <td className="border px-3 py-2">
                          <span
                            className="inline-block px-2 py-1 rounded text-white text-xs font-medium whitespace-nowrap"
                            style={{
                              backgroundColor: d.shift?.color || "#999",
                            }}
                          >
                            {d.description || d.shift?.long_name}
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          ))}
      </div>
       <ScrollToTopButton />
    </div>
  );
}

function getWeekNumber(isoDate: string): string {
  const date = parseISO(isoDate);
  const jan1 = new Date(date.getFullYear(), 0, 1);
  const days = Math.floor(
    (date.getTime() - jan1.getTime()) / (24 * 60 * 60 * 1000)
  );
  return String(Math.ceil((days + jan1.getDay() + 1) / 7));
}
