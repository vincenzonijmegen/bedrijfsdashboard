// src/app/admin/contacten/index.ts

export { default as CollapsibleGroup } from './CollapsibleGroup';
export { default as CompanyCard } from './CompanyCard';
export { default as CompanyModal } from './CompanyModal';
export { default as CorrespondentieModal } from './CorrespondentieModal';
