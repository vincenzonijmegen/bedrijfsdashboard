// src/app/admin/medewerker/[email]/dashboard/page.tsx

import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import MedewerkerDashboard from "@/components/medewerker/Dashboard";

interface PageProps {
  params: { email: string };
}

export default async function AdminMedewerkerDashboard({ params }: PageProps) {
  const email = decodeURIComponent(params.email);

  // Haal medewerker op
  const { rows } = await db.query(
    `SELECT id, naam, functie FROM medewerkers WHERE email = $1`,
    [email]
  );
  const medewerker = rows[0];

  if (!medewerker) return notFound();

  return (
    <main className="p-6">
      <div className="mb-4">
        <p className="text-sm text-gray-500">
          👀 Je bekijkt het dashboard van <strong>{medewerker.naam}</strong> in readonly-modus.
        </p>
      </div>

      <MedewerkerDashboard
        email={email}
        functie={medewerker.functie}
        readonly={true}
      />
    </main>
  );
}
