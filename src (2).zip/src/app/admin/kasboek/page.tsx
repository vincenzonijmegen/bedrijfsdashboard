import KasboekComponent from "@/components/KasboekComponent";

export default function Page() {
  return <KasboekComponent />;
}
