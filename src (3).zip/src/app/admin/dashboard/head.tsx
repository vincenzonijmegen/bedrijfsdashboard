// src/app/admin/dashboard/head.tsx
import React from 'react';

// src/app/head.tsx
export default function Head() {
  return (
    <>
      {/* … je bestaande tags … */}
      <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/icons/apple-touch-icon.png"
      />
    </>
  )
}

