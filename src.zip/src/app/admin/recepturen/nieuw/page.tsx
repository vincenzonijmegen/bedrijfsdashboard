"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

type CategorieItem = {
  slug: string;
  naam: string;
  sortering: number;
};

type Ingredient = {
  naam: string;
  gewicht: string;
};

export default function NieuwReceptPage() {
  const router = useRouter();

  const [naam, setNaam] = useState("");
  const [maakvolgorde, setMaakvolgorde] = useState(50);
  const [categorie, setCategorie] = useState("");
  const [categorieen, setCategorieen] = useState<CategorieItem[]>([]);
  const [hoeveelheidMix, setHoeveelheidMix] = useState("");
  const [maakinstructie, setMaakinstructie] = useState("");
  const [actief, setActief] = useState(true);
  const [ingredienten, setIngredienten] = useState<Ingredient[]>([
    { naam: "", gewicht: "" },
  ]);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadCategorieen() {
      try {
        const res = await fetch("/api/keuken/categorieen", {
          cache: "no-store",
        });
        const data = await res.json();

        if (res.ok && data.success) {
          const items: CategorieItem[] = data.items || [];
          setCategorieen(items);

          if (items.length > 0) {
            setCategorie((prev) => prev || items[0].slug);
          }
        }
      } catch (error) {
        console.error(error);
      }
    }

    loadCategorieen();
  }, []);

  function updateIngredient(
    index: number,
    field: keyof Ingredient,
    value: string
  ) {
    setIngredienten((prev) =>
      prev.map((item, i) =>
        i === index ? { ...item, [field]: value } : item
      )
    );
  }

  function addIngredient() {
    setIngredienten((prev) => [...prev, { naam: "", gewicht: "" }]);
  }

  function removeIngredient(index: number) {
    setIngredienten((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");

    try {
      const res = await fetch("/api/admin/recepturen", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          naam,
          categorie,
          hoeveelheid_mix: hoeveelheidMix,
          maakinstructie,
          actief,
          maakvolgorde,
          ingredienten,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data.error || "Opslaan mislukt");
        setSaving(false);
        return;
      }

      router.push("/admin/recepturen");
      router.refresh();
    } catch (error) {
      console.error(error);
      setError("Opslaan mislukt");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="max-w-5xl mx-auto p-6">
      <div className="mb-6 flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-wide text-slate-500">
            Admin
          </p>
          <h1 className="text-3xl font-bold text-slate-900">Nieuw recept</h1>
          <p className="mt-2 text-slate-600">
            Voeg een nieuwe keukenreceptuur toe.
          </p>
        </div>

        <Link
          href="/admin/recepturen"
          className="inline-flex items-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
        >
          ← Terug naar overzicht
        </Link>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-xl font-semibold text-slate-900">Basisgegevens</h2>

          <div className="mt-5 grid gap-5 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Naam
              </label>
              <input
                value={naam}
                onChange={(e) => setNaam(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
                placeholder="Bijv. Amarena"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Categorie
              </label>
              <select
                value={categorie}
                onChange={(e) => setCategorie(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
              >
                {categorieen.map((cat) => (
                  <option key={cat.slug} value={cat.slug}>
                    {cat.naam}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Hoeveelheid mix
              </label>
              <input
                value={hoeveelheidMix}
                onChange={(e) => setHoeveelheidMix(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
                placeholder="Bijv. 5 liter"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Maakvolgorde
              </label>

              <input
                type="number"
                value={maakvolgorde}
                onChange={(e) => setMaakvolgorde(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
              />

              <p className="mt-1 text-xs text-slate-500">
                Lager = eerder maken (bijv. yoghurt 10, snickers 90)
              </p>
            </div>

            <div className="flex items-end">
              <label className="inline-flex items-center gap-3 rounded-xl border border-slate-200 px-4 py-3">
                <input
                  type="checkbox"
                  checked={actief}
                  onChange={(e) => setActief(e.target.checked)}
                />
                <span className="text-sm font-medium text-slate-700">
                  Actief
                </span>
              </label>
            </div>

            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Maakinstructie
              </label>
              <textarea
                value={maakinstructie}
                onChange={(e) => setMaakinstructie(e.target.value)}
                rows={8}
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
                placeholder={`1. Base afwegen
2. Pasta toevoegen
3. Goed mixen
4. In bak doen en afdraaien`}
              />
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-xl font-semibold text-slate-900">
              Benodigdheden
            </h2>

            <button
              type="button"
              onClick={addIngredient}
              className="rounded-lg bg-slate-100 px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-200"
            >
              + Regel toevoegen
            </button>
          </div>

          <div className="mt-5 space-y-3">
            {ingredienten.map((ing, index) => (
              <div
                key={index}
                className="grid gap-3 rounded-xl border border-slate-200 p-4 md:grid-cols-[1fr_180px_auto]"
              >
                <input
                  value={ing.naam}
                  onChange={(e) =>
                    updateIngredient(index, "naam", e.target.value)
                  }
                  className="rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
                  placeholder="Benodigdheid"
                />

                <input
                  value={ing.gewicht}
                  onChange={(e) =>
                    updateIngredient(index, "gewicht", e.target.value)
                  }
                  className="rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-pink-500"
                  placeholder="Gewicht"
                />

                <button
                  type="button"
                  onClick={() => removeIngredient(index)}
                  disabled={ingredienten.length === 1}
                  className="rounded-lg border border-slate-300 px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40"
                >
                  Verwijderen
                </button>
              </div>
            ))}
          </div>
        </div>

        {error ? (
          <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="rounded-lg bg-pink-600 px-5 py-3 text-sm font-medium text-white shadow hover:bg-pink-700 disabled:opacity-60"
          >
            {saving ? "Opslaan..." : "Recept opslaan"}
          </button>

          <Link
            href="/admin/recepturen"
            className="rounded-lg border border-slate-300 bg-white px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            Annuleren
          </Link>
        </div>
      </form>
    </main>
  );
}