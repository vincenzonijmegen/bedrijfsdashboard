import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const geldigeStatussen = [
  "nieuw",
  "uitgenodigd",
  "gesprek gepland",
  "in de wacht",
  "wacht op gegevens",
  "aangenomen",
  "afgewezen",
];

const checklistVelden = [
  "id_ontvangen",
  "iban_ontvangen",
  "loonheffing_ontvangen",
  "pasfoto_ontvangen",
  "employes_ingevoerd",
  "shiftbase_ingevoerd",
  "vincenzo_app_ingevoerd",
  "whatsapp_vincenzo",
  "whatsapp_ruilen",
];

function cleanOptional(value: unknown) {
  if (value === undefined) return undefined;
  const cleaned = String(value ?? "").trim();
  return cleaned || null;
}

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  const result = await db.query(`SELECT * FROM sollicitaties WHERE id = $1`, [
    id,
  ]);

  if (result.rowCount === 0) {
    return NextResponse.json(
      { success: false, error: "Sollicitatie niet gevonden" },
      { status: 404 }
    );
  }

  return NextResponse.json(result.rows[0]);
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await req.json();

    const status =
      body?.status === undefined ? undefined : String(body.status).trim();

    const gesprekDatum = cleanOptional(body?.gesprek_datum);
    const gesprekNotities = cleanOptional(body?.gesprek_notities);

    const gesprekVelden = {
      ervaring: cleanOptional(body?.ervaring),
      opleiding: cleanOptional(body?.opleiding),
      rekenen: cleanOptional(body?.rekenen),
      kassa: cleanOptional(body?.kassa),
      duits: cleanOptional(body?.duits),
      extra: cleanOptional(body?.extra),
    };

    if (status !== undefined && !geldigeStatussen.includes(status)) {
      return NextResponse.json(
        { success: false, error: "Ongeldige status" },
        { status: 400 }
      );
    }

    await db.query(
      `
      UPDATE sollicitaties
      SET
        status = COALESCE($1, status),
        gesprek_datum = COALESCE($2::timestamp, gesprek_datum),
        gesprek_notities = COALESCE($3, gesprek_notities),

        ervaring = COALESCE($4, ervaring),
        opleiding = COALESCE($5, opleiding),
        rekenen = COALESCE($6, rekenen),
        kassa = COALESCE($7, kassa),
        duits = COALESCE($8, duits),
        extra = COALESCE($9, extra),

        aangenomen_op = CASE
          WHEN $1 = 'aangenomen' THEN COALESCE(aangenomen_op, NOW())
          ELSE aangenomen_op
        END,
        afgewezen_op = CASE
          WHEN $1 = 'afgewezen' THEN COALESCE(afgewezen_op, NOW())
          ELSE afgewezen_op
        END
      WHERE id = $10
      `,
      [
        status ?? null,
        gesprekDatum,
        gesprekNotities,
        gesprekVelden.ervaring,
        gesprekVelden.opleiding,
        gesprekVelden.rekenen,
        gesprekVelden.kassa,
        gesprekVelden.duits,
        gesprekVelden.extra,
        id,
      ]
    );

    for (const veld of checklistVelden) {
      if (body[veld] !== undefined) {
        await db.query(
          `
          UPDATE sollicitaties
          SET ${veld} = $1
          WHERE id = $2
          `,
          [Boolean(body[veld]), id]
        );
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Fout bij aanpassen sollicitatie:", error);

    return NextResponse.json(
      { success: false, error: "Serverfout" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;

    const result = await db.query(
      `
      DELETE FROM sollicitaties
      WHERE id = $1
      RETURNING id
      `,
      [id]
    );

    if (result.rowCount === 0) {
      return NextResponse.json(
        { success: false, error: "Sollicitatie niet gevonden" },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Fout bij verwijderen sollicitatie:", error);

    return NextResponse.json(
      { success: false, error: "Verwijderen mislukt" },
      { status: 500 }
    );
  }
}