"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { decode } from "html-entities";

interface Props {
  html: string;
  instructie_id: string;
  titel: string;
  terugHref?: string;
  terugLabel?: string;
}

type Vraag = {
  vraag: string;
  opties: string[];
  antwoord: string;
};

export default function StapVoorStapMetToets({
  html,
  instructie_id,
  titel,
  terugHref = "/instructies",
  terugLabel = "Terug naar instructies",
}: Props) {
  const [stappen, setStappen] = useState<string[]>([]);
  const [vragen, setVragen] = useState<Vraag[]>([]);
  const [index, setIndex] = useState(0);
  const [fase, setFase] = useState<"stappen" | "vragen" | "klaar">("stappen");
  const [heeftToets, setHeeftToets] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [aantalJuist, setAantalJuist] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const startTijd = useRef<number | null>(null);
  const [fouten, setFouten] = useState<
    { vraag: string; gegeven: string; gekozenTekst: string }[]
  >([]);
  const beantwoordeVragen = useRef<Set<number>>(new Set());

  useEffect(() => {
    startTijd.current = Date.now();

    return () => {
      const eindTijd = Date.now();
      const duurSec = Math.max(
        1,
        Math.floor((eindTijd - (startTijd.current || eindTijd)) / 1000)
      );

      let gebruiker: { email?: string; naam?: string; functie?: string } = {};
      try {
        gebruiker = JSON.parse(localStorage.getItem("gebruiker") || "{}");
      } catch {
        gebruiker = {};
      }

      fetch("/api/instructielog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        keepalive: true,
        body: JSON.stringify({
          email: gebruiker.email,
          naam: gebruiker.naam,
          functie: gebruiker.functie,
          titel,
          instructie_id,
          duur_seconden: duurSec,
        }),
      });
    };
  }, [instructie_id, titel]);

  useEffect(() => {
    let gebruiker: { email?: string } = {};
    try {
      gebruiker = JSON.parse(localStorage.getItem("gebruiker") || "{}");
    } catch {
      gebruiker = {};
    }

    if (gebruiker?.email && instructie_id) {
      fetch("/api/instructiestatus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: gebruiker.email, instructie_id }),
      });
    }

    const parts = html.split(/\[end\]/gi);

    const fixImgTags = (html: string) =>
      html.replace(
        /<img([^>]+?)style="[^"]*?">/gi,
        '<img$1 style="max-width: 100%; display: block; margin: 1em auto;" />'
      );

    const stepSegments = parts
      .slice(0, -1)
      .map((s) => fixImgTags(typeof s === "string" ? s.trim() : ""))
      .filter(Boolean);

    const vraagDeel = parts.slice(-1)[0] || "";
    const vragenHTML = vraagDeel.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ");

    const questionPattern =
      /Vraag[:.]\s*([\s\S]*?)\s*A\.\s*([\s\S]*?)\s*B\.\s*([\s\S]*?)\s*C\.\s*([\s\S]*?)\s*Antwoord:\s*([ABC])/gi;

    const vraagMatches = Array.from(vragenHTML.matchAll(questionPattern)).map((m) => ({
      vraag: m[1]?.trim() ?? "",
      opties: [m[2]?.trim() ?? "", m[3]?.trim() ?? "", m[4]?.trim() ?? ""],
      antwoord: m[5]?.trim()?.toUpperCase() ?? "",
    }));

    setStappen(stepSegments);
    setVragen(vraagMatches);
    setHeeftToets(vraagMatches.length > 0);

    setIndex(0);
    setFase("stappen");
    setFeedback(null);
    setScore(0);
    setAantalJuist(0);
    setFouten([]);
    beantwoordeVragen.current = new Set();
  }, [instructie_id, html]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key !== "Enter") return;

      if (fase === "vragen") {
        if (feedback && heeftToets) {
          e.preventDefault();
          naarVolgende();
        }
        return;
      }

      if (fase === "stappen") {
        e.preventDefault();
        naarVolgende();
      }
    };

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [fase, feedback, heeftToets, index]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    let startX = 0;

    const onTouchStart = (e: TouchEvent) => {
      startX = e.touches[0].clientX;
    };

    const onTouchEnd = (e: TouchEvent) => {
      const delta = e.changedTouches[0].clientX - startX;

      if (delta < -40) {
        if (fase === "vragen") {
          if (feedback) {
            setIndex((i) => Math.min(i + 1, vragen.length - 1));
          }
        } else {
          setIndex((i) => Math.min(i + 1, stappen.length - 1));
        }
      }

      if (delta > 40) {
        setIndex((i) => Math.max(i - 1, 0));
      }
    };

    el.addEventListener("touchstart", onTouchStart);
    el.addEventListener("touchend", onTouchEnd);

    return () => {
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchend", onTouchEnd);
    };
  }, [fase, feedback, stappen.length, vragen.length]);

  const selectAntwoord = (letter: "A" | "B" | "C") => {
    if (feedback != null) return;
    if (!vragen[index]) return;
    if (beantwoordeVragen.current.has(index)) return;

    beantwoordeVragen.current.add(index);

    const juist = letter === vragen[index].antwoord;

    if (juist) {
      setAantalJuist((n) => n + 1);
    } else {
      setFouten((f) => [
        ...f,
        {
          vraag: vragen[index].vraag,
          gegeven: letter,
          gekozenTekst: vragen[index].opties[["A", "B", "C"].indexOf(letter)],
        },
      ]);
    }

    setFeedback(
      juist ? "✅ Goed!" : `❌ Fout. Juiste antwoord: ${vragen[index].antwoord}`
    );
  };

  const naarVolgende = () => {
    setFeedback(null);

    let gebruiker: { email?: string; naam?: string; functie?: string } = {};
    try {
      gebruiker = JSON.parse(localStorage.getItem("gebruiker") || "{}");
    } catch {
      gebruiker = {};
    }

    if (fase === "stappen" && index === stappen.length - 1 && heeftToets) {
      setFase("vragen");
      setIndex(0);
      return;
    }

    if (fase === "vragen" && index === vragen.length - 1 && heeftToets) {
      const veiligAantalJuist = Math.min(aantalJuist, vragen.length);
      const percentage =
        vragen.length > 0
          ? Math.round((veiligAantalJuist / vragen.length) * 100)
          : 0;

      setScore(percentage);
      setFase("klaar");

      fetch("/api/resultaten", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: gebruiker.email,
          naam: gebruiker.naam,
          functie: gebruiker.functie,
          titel,
          instructie_id,
          score: percentage,
          juist: veiligAantalJuist,
          totaal: vragen.length,
          fouten,
        }),
      });
      return;
    }

    if (!heeftToets && index === stappen.length - 1) {
      setFase("klaar");
      return;
    }

    if (fase === "vragen" && feedback == null) {
      return;
    }

    setIndex((i) => i + 1);
  };

  return (
    <div
      ref={containerRef}
      className="mx-auto flex min-h-screen max-w-4xl flex-col bg-slate-50"
    >
      <div className="p-4 pb-28 space-y-4">
        <h1 className="text-2xl font-bold">{titel}</h1>

        {fase === "stappen" && (
          <div
            className="min-h-[150px] rounded border bg-white p-4 shadow prose prose-blue max-w-none"
            dangerouslySetInnerHTML={{
              __html: decode(
                (stappen[index] || "").replace(
                  /<a[^>]*href=["'](https?:\/\/(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)[^"']+)["'][^>]*>[\s\S]*?<\/a>/gi,
                  (_match, url) => {
                    const rawId = url.includes("watch?v=")
                      ? url.split("watch?v=")[1].split("&")[0]
                      : url.split("/").pop()?.split("?")[0] || "";

                    return `<iframe
                      class="w-full aspect-video rounded mb-4"
                      src="https://www.youtube.com/embed/${rawId}"
                      frameborder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowfullscreen
                    ></iframe>`;
                  }
                )
              ),
            }}
          />
        )}

        {fase === "vragen" && vragen[index] && (
          <div className="space-y-4 rounded border bg-white p-4 shadow">
            <h2 className="text-xl font-semibold">Vraag {index + 1}</h2>
            <p>{vragen[index].vraag}</p>
            <div className="space-y-2">
              {["A", "B", "C"].map((letter, i) => (
                <button
                  key={letter}
                  onClick={() => selectAntwoord(letter as "A" | "B" | "C")}
                  className="block w-full rounded border bg-white px-4 py-2 text-left hover:bg-blue-50"
                  disabled={feedback != null}
                >
                  {letter}. {vragen[index].opties[i]}
                </button>
              ))}
            </div>

            {feedback && (
              <div className="mt-2 text-sm">
                {feedback}
                <div className="mt-2">
                  <button
                    onClick={naarVolgende}
                    className="rounded bg-blue-600 px-4 py-2 text-white"
                  >
                    {index === vragen.length - 1
                      ? "Bekijk resultaat"
                      : "Volgende vraag (↵)"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {fase === "klaar" && (
          <div className="space-y-4 text-center text-xl font-semibold">
            {heeftToets ? (
              <p className={score >= 80 ? "text-green-700" : "text-red-700"}>
                {score >= 80 ? "✅ Geslaagd!" : "❌ Niet geslaagd."} Je score: {score}%
                <br />
                {Math.min(aantalJuist, vragen.length)} van {vragen.length} goed
                beantwoord
              </p>
            ) : (
              <p className="text-green-700">✅ Instructie gelezen</p>
            )}

            <Link
              href={terugHref}
              className="inline-block rounded bg-blue-600 px-4 py-2 text-white transition hover:bg-blue-700"
            >
              {terugLabel}
            </Link>
          </div>
        )}
      </div>

      {fase === "stappen" && (
        <div className="fixed inset-x-0 bottom-0 z-20 border-t border-slate-200 bg-white/95 p-4 backdrop-blur">
          <div className="mx-auto flex max-w-4xl justify-between gap-3">
            <button
              onClick={() => setIndex((i) => Math.max(i - 1, 0))}
              disabled={index === 0}
              className="rounded bg-gray-300 px-4 py-3 disabled:opacity-40"
            >
              Vorige
            </button>

            <button
              onClick={naarVolgende}
              className="rounded bg-blue-600 px-4 py-3 text-white"
            >
              {index === stappen.length - 1 && heeftToets
                ? "Start toets (↵)"
                : "Volgende stap (↵)"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}